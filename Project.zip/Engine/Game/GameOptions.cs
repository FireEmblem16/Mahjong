﻿namespace Engine.Game
{
	/// <summary>
	/// Specifices options for a game.
	/// </summary>
	public interface GameOptions
	{}
}
